Instruction:
1. Unzip the file in a directory

1.1 create a virtual environment using the command: $python -m venv venv

1.2 enable the virtual environment, by executing the activate.bat file:$ venv\Scripts\activate

2.execute the main file in cmd as $python eval.py

3.it takes all the images as input from the folder "input_images"

4. the extracted text are stored as a json file with corresponding image name in the folder "output_jsons" with the corresponding file 